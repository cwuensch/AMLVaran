options(stringsAsFactors=FALSE)
library(R6)
library(rlist)
library(plyr)
library(jsonlite)
library(httr)
library(readxl)


Annotator <- R6Class(classname="Annotator", portable=FALSE,
  private = list(
    pathQualTool = paste(getSrcDirectory(function(x){x}), "RunQT", sep="/"),
    AllSamples = NULL,
    ArtiScore = NULL,
    PolyScore = NULL,
    Result = NULL,
    ArtiProt = NULL,
    PolyProt = NULL,
    NrClinicalDBs = NULL,
    NrNonClinicalDBs = NULL,
    NrAnyDBs = NULL,
    special = NULL,
    previous = NULL,
    current = NULL
  ),

  public = list(
    VariantList = NULL,
    FilterScheme = NULL,

    # Constructor
    initialize = function(pVariantList)
    {
      VariantList <<- pVariantList;
      initScores();
    },
                     
    # Declare functions, that can be used by filter scheme here
    # =========================================================
    x = function(name)
    {
      if (name %in% names(VariantList))
        VariantList[,name]
      else
        rep(NA, nrow(VariantList));
    },
    
    isEmpty = function(input)
    {
      is.na(input) | input=="" | input==" ";
    },
    
    stringContains = function(haystack, needle)
    {
      grepl(needle, haystack);
    },
    
    stringConcat = paste0,
    strLength = nchar,
    parseFloat = as.numeric,
    
    
    # READ FILTER SCHEME
    # ==================
    # Create a function from a string
    makeFuncFromStr = function(str)
    {
      str = paste('function(t) {', str, '}');
#      str = gsub('IIF', 'ifelse', str);
#      str = gsub('THEN', ', ', str);
#      str = gsub('ELSE', ', ', str);
      str = gsub('true', 'TRUE', str);
      str = gsub('false', 'FALSE', str);
      str = gsub(':=', '<<-', str);
      str = gsub('\\&\\&', '&', str);
      str = gsub('\\|\\|', '|', str);
      str = gsub('max\\(', 'pmax(', str);
      str = gsub('min\\(', 'pmin(', str);
      for (i in c(3,2,1,0))
        str = gsub(paste0('t\\[', i, '\\]'), paste0('t[', i+1, ']'), str);
      eval(parse(text=str))
    },
    
    # Read scheme from JSON file
    loadFilterScheme = function(inputFile)
    {
      json=jsonlite::fromJSON(inputFile, simplifyDataFrame=FALSE, simplifyMatrix=FALSE, simplifyVector=FALSE);
    
      FilterScheme <<- list()
      for (Category in json)
      {
        print(Category['Caption']);
        for (Entry in Category[['Entries']])
        {
          SubFunctions = NULL
      
          if ((Entry[['Type']] == 'AND-Node') || (Entry[['Type']] == 'OR-Node'))
          {
            SubFunctions = list()
            for (SubEntry in Entry[['Entries']])
            {
              SubFunctions = list.append(SubFunctions, list(Func=makeFuncFromStr(SubEntry[['Condition']]), Type=SubEntry[['Type']], Default=unlist(SubEntry[['Default']]), ArtiScore=SubEntry[['ArtiScore']], PolyScore=SubEntry[['PolyScore']], Result=SubEntry[['Result']], Prot=SubEntry[['Protocoll']]));
            }
          }
          FilterScheme <<- list.append(FilterScheme, list(Func=makeFuncFromStr(Entry[['Condition']]), Type=Entry[['Type']], Default=unlist(Entry[['Default']]), ArtiScore=Entry[['ArtiScore']], PolyScore=Entry[['PolyScore']], Result=Entry[['Result']], Prot=Entry[['Protocoll']], SubEntries=SubFunctions));
        }
      }
      FilterScheme;
    },
    
    
    # SCORE CALCULATION
    # =================
    # Initialize class variables
    initScores = function()
    {
      AllSamples <<- length(unique(VariantList[,"SampleID"]));
      ArtiScore  <<- integer(length = nrow(VariantList));
      PolyScore  <<- integer(length = nrow(VariantList));
      Result     <<- rep('Probably True', nrow(VariantList));
      ArtiProt   <<- character(length = nrow(VariantList));
      PolyProt   <<- character(length = nrow(VariantList));
      NrClinicalDBs <<- integer(length = nrow(VariantList));
      NrNonClinicalDBs <<- integer(length = nrow(VariantList));
      NrAnyDBs   <<- integer(length = nrow(VariantList));
      special    <<- logical(length = nrow(VariantList));
      previous   <<- logical(length = nrow(VariantList));
      current    <<- logical(length = nrow(VariantList));
    },
    
    # Update a Score, incl. output of Protocoll String
    increaseScore = function(ResultVector, IncreaseBy, ProtocollStr, ArtiPoly)
    {
      if (!is.null(IncreaseBy) && (IncreaseBy != 0) && (IncreaseBy != ""))
      {
        IncreaseVector = ifelse(ResultVector & !is.na(ResultVector), IncreaseBy, 0);
        ProtVector = ifelse(ResultVector & !is.na(ResultVector), paste(IncreaseBy, ProtocollStr, sep=': '), '');
        if (ArtiPoly == 'arti')
        {
          ArtiScore <<- ArtiScore + IncreaseVector;
          ArtiProt  <<- paste(ArtiProt, ProtVector, sep="|");
        }
        else if (ArtiPoly == 'poly')
        {
          PolyScore <<- PolyScore + IncreaseVector;
          PolyProt  <<- paste(PolyProt, ProtVector, sep="|");
        }
        else if (ArtiPoly == 'result')
        {
          Result <<- ifelse(ResultVector & !is.na(ResultVector), IncreaseBy, Result);
        }
      }
    },
    
    # Apply Filter Scheme to Variant List
    applyFilters = function()
    {
      initScores();
      for (Entry in FilterScheme)
      {
        previous <<- current;  # hier ist previous der letzte (Sub-)Eintrag, bzw. bei OR-Node das Oder aller Sub-Entries

        if (Entry[['Type']] == 'OR-Node')
        {
          current <<- logical(length = nrow(VariantList));
          for (SubEntry in Entry[['SubEntries']])
          {
            previous <<- current;  # hier ist previous das ODER aller bisherigen Sub-Entries
            current <<- current | SubEntry[['Func']](SubEntry[['Default']]);
          }
        }
        else
          current <<- Entry[['Func']](Entry[['Default']]);
      
        increaseScore(current, Entry[['ArtiScore']], Entry[['Prot']], 'arti');
        increaseScore(current, Entry[['PolyScore']], Entry[['Prot']], 'poly');
        increaseScore(current, Entry[['Result']], NA, 'result');
        
        if (Entry[['Type']] == 'AND-Node')
        {
          curAND = current;
          for (SubEntry in Entry[['SubEntries']])
          {
            previous <<- current;  # hier ist previous der letzte Sub-Entry
            current <<- curAND & SubEntry[['Func']](SubEntry[['Default']]);
            increaseScore(current, SubEntry[['ArtiScore']], SubEntry[['Prot']], 'arti');
            increaseScore(current, SubEntry[['PolyScore']], SubEntry[['Prot']], 'poly');
            increaseScore(current, SubEntry[['Result']], NA, 'result');
          }
        }
      }
      VariantList[,"Result"] <<- Result;
      VariantList[,"ArtiScore"] <<- ArtiScore;
      VariantList[,"PolyScore"] <<- PolyScore;
      VariantList[,"ArtiProt"] <<- ArtiProt;
      VariantList[,"PolyProt"] <<- PolyProt;
      VariantList;
    },
    
    
    # ANNOTATION
    # ==========
    # Normalize all variants in dataframe, old values are stored in pos_o, ref_o, alt_o
    Normalize = function(VariantList)
    {
      VariantList[,'pos_o'] <- VariantList[,'pos'];
      VariantList[,'ref_o'] <- VariantList[,'ref'];
      VariantList[,'alt_o'] <- VariantList[,'alt'];
      for (row in 1:nrow(VariantList)) {
        pos = VariantList[row, 'pos'];
        ref = VariantList[row, 'ref'];
        alt = VariantList[row, 'alt'];
        while (substring(ref, 1, 1) == substring(alt, 1, 1))
        {
          ref = substring(ref, 2);
          alt = substring(alt, 2);
          pos = pos + 1;
          if (ref == "") ref = "-";
          if (alt == "") alt = "-";
        }
        VariantList[row, 'pos'] <- pos;
        VariantList[row, 'ref'] <- ref;
        VariantList[row, 'alt'] <- alt;
      }
      VariantList;
    },

    Unnormalize = function(VariantList)
    {
      VariantList[,"pos"] <- VariantList[,"pos_o"];
      VariantList[,"ref"] <- VariantList[,"ref_o"];
      VariantList[,"alt"] <- VariantList[,"alt_o"];
      VariantList[,"pos_o"] <- NULL;
      VariantList[,"ref_o"] <- NULL;
      VariantList[,"alt_o"] <- NULL;
      VariantList;
    },
    
    # Retrieves annotation information from webserver
    getAnnotation = function()
    {
      # 1. Prepare request
      VariantList <<- Normalize(VariantList);
      json = jsonlite::toJSON(unique(VariantList[c("chr", "pos", "ref", "alt")]), dataframe="rows");
      
      # 2. Send request
      res = httr::POST("https://annoserv.uni-muenster.de/annopost.php", body=json, encode="json");
      annos = httr::content(res, as="parsed");

      # 3. Parse result
      annos = lapply(annos, function(x) {
        x[sapply(x, is.null)] <- NA;
        x;
      })
      annos = do.call(rbind, lapply(annos, data.frame));
      
      # 4. Join results
      VariantList <<- join(VariantList, annos, by=c("chr", "pos", "ref", "alt"), type="left", match="first");
      VariantList <<- Unnormalize(VariantList);
      VariantList;
    },
    
    
    # QUALITY ANALYSIS
    # ================
    getQualities = function(bamDir, fastaFile)
    {
      # 1. Write input file
      VariantList <<- Normalize(VariantList);
      write.table(VariantList[c("SampleID", "chr", "pos", "ref", "alt")], file=paste(tempdir(), "QualIn.txt", sep="/"), sep=';', col.names=TRUE, row.names=FALSE, quote=FALSE, append=FALSE);

      # 2. Run Quality Tool
      system2(pathQualTool, c("-f", fastaFile, "-b", bamDir, "-i", paste(tempdir(), "QualIn.txt", sep="/"), "-o", paste(tempdir(), "QualOut.txt", sep="/")), wait=TRUE, invisible=FALSE);

      # 3. Parse result
      quals = read.csv(file=paste(tempdir(), "/QualOut.txt", sep=""), sep=";", header=TRUE);

      # 4. Count occurance of variants  
      NrSamples = ddply(VariantList, .(chr, pos, ref, alt), nrow);
      NrSamples = rename(NrSamples, c("V1" = "NrSamples"));
      NrSamplesSimilar = ddply(VariantList, .(chr, pos), nrow);
      NrSamplesSimilar = rename(NrSamplesSimilar, c("V1" = "NrSamplesSimilar"));
      NrSamplesHighVAF = ddply(quals[quals[,"VAF"]>0.85,], .(chr, pos, ref, alt), nrow);
      NrSamplesHighVAF = rename(NrSamplesHighVAF, c("V1" = "NrSamplesHighVAF"));
      
      # 5. Join result
      VariantList <<- join(VariantList, quals, by=c("SampleID", "chr", "pos", "ref", "alt"), type="left", match="first");
      VariantList <<- join(VariantList, NrSamples, by=c("chr", "pos", "ref", "alt"), type="left", match="first");
      VariantList <<- join(VariantList, NrSamplesSimilar, by=c("chr", "pos"), type="left", match="first");
      VariantList <<- join(VariantList, NrSamplesHighVAF, by=c("chr", "pos", "ref", "alt"), type="left", match="first");
      VariantList <<- Unnormalize(VariantList);

      # 6. Tidy up
      unlink(paste(tempdir(), "QualIn.txt", sep="/"));
      unlink(paste(tempdir(), "QualOut.txt", sep="/"));
      VariantList;
    }
  )
)
    
# MAIN PROGRAM
# ============

VariantList2 <- read.csv(file='Z:\\Promotion\\appreci8\\VariantList5_red.csv', sep=';', header=TRUE);
VariantList2 <- read.csv(file='Z:\\Promotion\\appreci8\\VariantList5.csv', sep=';', header=TRUE);

a = Annotator$new(VariantList2);
a$loadFilterScheme('Z:\\Promotion\\appreci8\\FilterScheme.json');

t1 = Sys.time();
VariantList_new = a$getAnnotation();
t2 = Sys.time();
VariantList_new = a$getQualities("S:\\Analyses\\Nijmegen_MDS_sequencing\\MDS-Triage\\Sweden_1\\alignment", "Z:\\Promotion\\QualityTool\\Homo_sapiens.GRCh37.67.dna.chromosome.all.fasta");
t3 = Sys.time();

VariantList_new = a$applyFilters();
t4 = Sys.time();

print(t2-t1);
print(t3-t2);
print(t4-t3);
